const Microfinance = artifacts.require("Microfinance");

module.exports = function (deployer) {
  // Deploy the Microfinance contract
  deployer.deploy(Microfinance);
};
