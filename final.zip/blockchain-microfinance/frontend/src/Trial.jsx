// src/Trial.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate hook
import './Trial.css'; // Import the CSS file
import S from './assets/c.jpg';

function Trial() {
    const [profile, setProfile] = useState({ name: "", address: "", balance: 0 });
    const [name, setName] = useState("");
    const [amount, setAmount] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [successMessage, setSuccessMessage] = useState("");

    const navigate = useNavigate(); // Initialize useNavigate

    const updateName = () => {
        if (!name) return;
        setLoading(true);
        setError("");
        setSuccessMessage("");
        setTimeout(() => {
            setProfile({ ...profile, name });
            setSuccessMessage("Successfully Updated Profile");
            setLoading(false);
        }, 1000);
    };

    const addBalance = () => {
        if (isNaN(amount) || parseFloat(amount) <= 0) return;
        setLoading(true);
        setError("");
        setSuccessMessage("");
        setTimeout(() => {
            setProfile({ ...profile, balance: parseFloat(profile.balance) + parseFloat(amount) });
            setSuccessMessage("Successfully Added Balance");
            setLoading(false);
        }, 1000);
    };

    const uploadProfile = () => {
        if (!name || isNaN(amount) || parseFloat(amount) <= 0) return;
        setLoading(true);
        setError("");
        setSuccessMessage("");
        setTimeout(() => {
            setProfile({ name, address: "Sample Address", balance: parseFloat(amount) });
            setSuccessMessage("Successfully Uploaded Profile and Added Balance");
            setLoading(false);
        }, 1000);
    };

    return (
        <div className="trial-container" style={{ backgroundImage: `url(${S})` }}>
            <h1 className="title">Microfinance Dashboard</h1>
            {loading && <p className="status loading">Loading...</p>}
            {error && <p className="status error">{error}</p>}
            {successMessage && <p className="status success">{successMessage}</p>}
            <div className="info-section">
                <p><strong>Your Account:</strong> {profile.name || "N/A"}</p>
                <p><strong>Balance:</strong> {profile.balance || 0} ETH</p>
            </div>
            <div className="update-profile-add-balance-container">
                <div className="update-profile-section">
                    <h3>Update Profile</h3>
                    <input
                        type="text"
                        placeholder="Enter your name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                    />
                    <button onClick={updateName} disabled={loading}>Update Name</button>
                </div>
                <div className="add-balance-section">
                    <h3>Add Balance</h3>
                    <input
                        type="number"
                        placeholder="Amount in ETH"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                    />
                    <button onClick={addBalance} disabled={loading}>Add Balance</button>
                </div>
            </div>
            <div className="upload-profile-section">
                <h3>Upload Profile and Balance</h3>
                <button onClick={uploadProfile} disabled={loading}>Upload</button>
            </div>
            <button className="back-button" onClick={() => navigate("/")}>
                Back
            </button>
        </div>
    );
}

export default Trial;
