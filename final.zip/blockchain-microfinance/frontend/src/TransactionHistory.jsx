// src/TransactionHistory.jsx
import React, { useState, useEffect } from 'react';
import './TransactionHistory.css';

function TransactionHistory() {
    const [transactions, setTransactions] = useState([
        { name: 'John Doe', amount: 500, reason: 'Loan Request' },
        { name: 'Jane Smith', amount: 200, reason: 'Loan Funded' },
        { name: 'Alice Johnson', amount: 300, reason: 'Loan Repaid' },
    ]);

    useEffect(() => {
        // Fetch transactions from an API or database if needed
    }, []);

    return (
        <div className="transaction-history-container">
            <h1>Transaction History</h1>
            <button className="back-button" onClick={() => window.history.back()}>Back</button>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Loan Amount</th>
                        <th>Reason</th>
                    </tr>
                </thead>
                <tbody>
                    {transactions.map((transaction, index) => (
                        <tr key={index}>
                            <td>{transaction.name}</td>
                            <td>{transaction.amount}</td>
                            <td>{transaction.reason}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default TransactionHistory;
