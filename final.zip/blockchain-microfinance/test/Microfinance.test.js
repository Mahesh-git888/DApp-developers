const Microfinance = artifacts.require("Microfinance");

contract("Microfinance", (accounts) => {
    let microfinanceInstance;

    before(async () => {
        microfinanceInstance = await Microfinance.deployed();
    });

    it("should set user profile correctly", async () => {
        const name = "Alice";
        await microfinanceInstance.setUserProfile(name, { from: accounts[0] });

        const profile = await microfinanceInstance.getUserProfile(accounts[0]);
        assert.equal(profile[0], name, "The name was not set correctly in the profile.");
        assert.equal(profile[1], accounts[0], "The user address was not set correctly in the profile.");
        assert.equal(profile[2].toNumber(), 0, "The initial balance should be 0.");
    });

    it("should allow user to add balance", async () => {
        const amount = 1000;
        await microfinanceInstance.addBalance(amount, { from: accounts[0] });

        const profile = await microfinanceInstance.getUserProfile(accounts[0]);
        assert.equal(profile[2].toNumber(), amount, "The balance was not added correctly.");
    });

    it("should allow user to request a loan", async () => {
        const amount = 500;
        const interestRate = 5;
        const duration = 12; // 12 months

        await microfinanceInstance.requestLoan(amount, interestRate, duration, { from: accounts[1] });

        const loan = await microfinanceInstance.loans(1);
        assert.equal(loan.amount.toNumber(), amount, "Loan amount is incorrect.");
        assert.equal(loan.interestRate.toNumber(), interestRate, "Interest rate is incorrect.");
        assert.equal(loan.duration.toNumber(), duration, "Loan duration is incorrect.");
        assert.equal(loan.funded, false, "Loan should not be funded yet.");
        assert.equal(loan.repaid, false, "Loan should not be repaid yet.");
    });

    it("should allow user to fund a loan", async () => {
        const loanId = 1;
        const loan = await microfinanceInstance.loans(loanId);

        await microfinanceInstance.fundLoan(loanId, { from: accounts[2], value: loan.amount });

        const updatedLoan = await microfinanceInstance.loans(loanId);
        assert.equal(updatedLoan.funded, true, "Loan should be funded.");
    });

    it("should allow borrower to repay a loan", async () => {
        const loanId = 1;
        const loan = await microfinanceInstance.loans(loanId);
        const repaymentAmount = loan.amount.toNumber() + (loan.amount.toNumber() * loan.interestRate.toNumber() / 100);

        await microfinanceInstance.repayLoan(loanId, { from: accounts[1], value: repaymentAmount });

        const updatedLoan = await microfinanceInstance.loans(loanId);
        assert.equal(updatedLoan.repaid, true, "Loan should be repaid.");
    });
});
