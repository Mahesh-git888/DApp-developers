// src/RequestLoan.jsx
import React, { useState } from "react";
import './RequestLoan.css'; // Import the CSS file

function RequestLoan() {
    const [name, setName] = useState("");
    const [amount, setAmount] = useState("");
    const [reason, setReason] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [successMessage, setSuccessMessage] = useState("");

    const handleRequestLoan = () => {
        if (!name || isNaN(amount) || parseFloat(amount) <= 0 || !reason) {
            setError("Please fill in all fields correctly.");
            return;
        }
        setLoading(true);
        setError("");
        setSuccessMessage("");
        setTimeout(() => {
            setSuccessMessage("Loan Request Submitted Successfully");
            setLoading(false);
        }, 1000);
    };

    return (
        <div className="request-loan-container">
            <h1>Request Loan</h1>
            {loading && <p>Loading...</p>}
            {error && <p className="error">{error}</p>}
            {successMessage && <p className="success">{successMessage}</p>}
            <form>
                <input
                    type="text"
                    placeholder="Enter your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                <input
                    type="number"
                    placeholder="Amount of Loan"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Reason for Loan"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                />
                <button type="button" onClick={handleRequestLoan} disabled={loading}>
                    Submit Request
                </button>
            </form>
            <button className="back-button" onClick={() => window.history.back()}>
                Back
            </button>
        </div>
    );
}

export default RequestLoan;
