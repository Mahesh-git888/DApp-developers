// src/Navigation.jsx
import React from "react";
import { useNavigate } from "react-router-dom";
import './Nav.css';

function Navigation({ handleLogout }) {
    const navigate = useNavigate();

    const handleNavigation = (page) => {
        if (page === "transaction") {
            navigate("/transaction-history");
        }
        else if(page === "home") {
            navigate("/trial")

        }
         else {
            navigate(`/${page}`);
        }
    };

    return (
        <div className="navigation-container">
            <h1>Microfinance Dashboard</h1>
            <div className="block" onClick={() => handleNavigation("home")}>
                <h2>Home</h2>
            </div>
            <div className="block" onClick={() => handleNavigation("request-loan")}>
                <h2>Request Loan</h2>
            </div>
            <div className="block" onClick={() => handleNavigation("fund-loan")}>
                <h2>Fund Loan</h2>
            </div>
            <div className="block" onClick={() => handleNavigation("repay-loan")}>
                <h2>Repay Loan</h2>
            </div>
            <div className="block" onClick={() => handleNavigation("transaction")}>
                <h2>Transaction</h2>
            </div>
            <button onClick={handleLogout}>Logout</button>
        </div>
    );
}

export default Navigation;
