// src/App.jsx
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './Login';
import Signup from './Signup';
import Navigation from './Navigation';
import Trial from './Trial';
import RequestLoan from './RequestLoan';
import FundLoan from './FundLoan';
import RepayLoan from './RepayLoan';
import TransactionHistory from './TransactionHistory';
import './App.css';

function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [firstName, setFirstName] = useState('');
    const [showSignup, setShowSignup] = useState(false);

    useEffect(() => {
        const savedIsLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
        const savedFirstName = localStorage.getItem('firstName');
        if (savedIsLoggedIn) {
            setIsLoggedIn(true);
            setFirstName(savedFirstName);
        }
    }, []);

    const handleLogin = (name) => {
        setFirstName(name);
        setIsLoggedIn(true);
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('firstName', name);
    };

    const handleLogout = () => {
        setIsLoggedIn(false);
        setFirstName('');
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('firstName');
    };

    const toggleSignup = () => {
        setShowSignup(!showSignup);
    };

    return (
        <Router>
            <div className="App">
                {!isLoggedIn ? (
                    showSignup ? (
                        <Signup toggleSignup={toggleSignup} />
                    ) : (
                        <Login toggleSignup={toggleSignup} toggleLogin={handleLogin} />
                    )
                ) : (
                    <>
                        <Navigation handleLogout={handleLogout} />
                        <Routes>
                            <Route path="/trial" element={<Trial />} />
                            <Route path="/request-loan" element={<RequestLoan />} />
                            <Route path="/fund-loan" element={<FundLoan />} />
                            <Route path="/repay-loan" element={<RepayLoan />} />
                            <Route path="/transaction-history" element={<TransactionHistory />} />
                        </Routes>
                    </>
                )}
            </div>
        </Router>
    );
}

export default App;
