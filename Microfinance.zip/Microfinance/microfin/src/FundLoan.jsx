// src/FundLoan.jsx
import React, { useState } from 'react';
import './FundLoan.css'; // Import the CSS file

function FundLoan() {
    const [name, setName] = useState("");
    const [amount, setAmount] = useState("");
    const [reason, setReason] = useState("");
    const [loading, setLoading] = useState(false);
    const [successMessage, setSuccessMessage] = useState("");
    const [error, setError] = useState("");

    const handleFundLoan = () => {
        if (!name || isNaN(amount) || parseFloat(amount) <= 0 || !reason) {
            setError("Please fill in all fields correctly.");
            return;
        }
        setLoading(true);
        setError("");
        setSuccessMessage("");
        setTimeout(() => {
            setSuccessMessage("Loan Funded Successfully");
            setLoading(false);
            // You can add additional logic to handle the fund loan here
        }, 1000);
    };

    return (
        <div className="fund-loan-container">
            <h1>Fund Loan</h1>
            {loading && <p>Loading...</p>}
            {error && <p className="error">{error}</p>}
            {successMessage && <p className="success">{successMessage}</p>}
            <div className="fund-loan-form">
                <input
                    type="text"
                    placeholder="Enter your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                <input
                    type="number"
                    placeholder="Amount of Loan"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Reason for Loan"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                />
                <button onClick={handleFundLoan} disabled={loading}>Submit Funding</button>
            </div>
            <button className="back-button" onClick={() => window.history.back()}>Back</button>
        </div>
    );
}

export default FundLoan;
