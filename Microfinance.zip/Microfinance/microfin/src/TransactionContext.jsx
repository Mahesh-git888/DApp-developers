import React from 'react';
import { useTransaction } from './TransactionContext';
import './TransactionHistory.css';

function TransactionHistory() {
    const { transactions } = useTransaction();

    return (
        <div className="transaction-history-container">
            <h1>Transaction History</h1>
            <button className="back-button" onClick={() => window.history.back()}>Back</button>
            <div className="transaction-history-content">
                <div className="transaction-history-header">
                    <div>Name</div>
                    <div>Loan Amount</div>
                    <div>Reason</div>
                </div>
                <div className="transaction-history-body">
                    {transactions.map((transaction, index) => (
                        <div className="transaction-history-row" key={index}>
                            <div>{transaction.name}</div>
                            <div>{transaction.amount}</div>
                            <div>{transaction.reason}</div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default TransactionHistory;
